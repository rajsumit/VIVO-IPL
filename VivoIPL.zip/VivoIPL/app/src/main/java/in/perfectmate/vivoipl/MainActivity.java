package in.perfectmate.vivoipl;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.google.android.gms.ads.MobileAds;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MobileAds.initialize(this, "ca-app-pub-2145975861185066~5973876756");
    }

    //for opening schedule activity
    public void schedule(View view) {
        Intent i = new Intent(this, schedule.class);
        startActivity(i);
    }

    //for opening live score activity
    public void live_score(View view) {
        Intent i = new Intent(this, live_score.class);
        startActivity(i);
    }

    //for opening point table activity
    public void point_table(View view) {
        Intent i = new Intent(this, point_table.class);
        startActivity(i);
    }

    //for opening teams activity
    public void teams(View view) {
        Intent i = new Intent(this, teams.class);
        startActivity(i);
    }

    //for opening news activity
    public void news(View view) {
        Intent i = new Intent(this, news.class);
        startActivity(i);
    }
}



